#!/usr/bin/php-cgi7.1
<html>
<body>
<center>
<p><br>

<img src="./cap.jpg" height="350" width="350" ><br>
<font face=arial size=7 color=darkblue>Capibara Search</font>
<p>
<form enctype="multipart/form-data" action="./search.process.php" method="post">
<input name="myquery" size="60">
<input name="Search" value="search" type="submit"> </form>

</center>
</body>
</html>
