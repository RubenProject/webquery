rm webindex/*
rm linkindex/*
rm titleindex/*
rm pageindex/*
rm repository/*
./webspider http://www.tweakers.net
